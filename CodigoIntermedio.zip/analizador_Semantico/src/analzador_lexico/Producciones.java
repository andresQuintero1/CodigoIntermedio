/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package analzador_lexico;

import java.util.ArrayList;

/**
 *
 * @author FELIPE
 */
public class Producciones {
    
    private ArrayList<Token> tokens;
    private String tipo;
    private Producciones condicion;
    private Producciones hijo;
    private boolean anidado;
    
    public Producciones() {
        this.tokens = new ArrayList<Token>();
        this.anidado=false;
    }

    public boolean isAnidado() {
        return anidado;
    }

    public void setAnidado(boolean anidado) {
        this.anidado = anidado;
    }

    public Producciones getCondicion() {
        return condicion;
    }

    public void setCondicion(Producciones condicion) {
        this.condicion = condicion;
    }

    public Producciones getHijo() {
        return hijo;
    }

    public void setHijo(Producciones hijo) {
        this.hijo = hijo;
    }
    
    public String condition(){
        return this.condicion.StringTokens();
    }
    
    public String Son(){
        return this.hijo.StringTokens();
    }

    public ArrayList<Token> getTokens() {
        return tokens;
    }

    
    public void addTokens(Token s){
        this.tokens.add(s);
    }

    public String getTipo() {
        return tipo;
    }

    public void setTipo(String tipo) {
        this.tipo = tipo;
    }
    
    public String getToken(int x){
        return this.tokens.get(x).getToken();
    }
    
    public String getlex(int x){
        return this.tokens.get(x).getLex();
    }
    
    public String StringTokens(){
        String mensaje="";
        for(Token x :this.tokens){
            mensaje=mensaje+" "+x.getToken();
        }
        return mensaje;
    }
    
    
    
    
}
