/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package analzador_lexico;

/**
 *
 * @author FELIPE
 */
public class Token {
    private String token;
    private String lex;
    private int fila;
    private int columna;

    public Token(String t,String l, int x,int y){
        this.token=t;
        this.lex=l;
        this.fila=x;
        this.columna=y;
    }
    
    public String getToken(){
        return this.token;
    }
    
    public String getLex(){
        return this.lex;
    }
    
    public int getLinea(){
        return this.fila;
    }
    
    public int getCol(){
        return this.columna;
    }
}
