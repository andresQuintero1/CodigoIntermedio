/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package analzador_lexico;

import java.util.ArrayList;

/**
 *
 * @author FELIPE
 */
public class AnalizadorSintactico {
    private Token[] tokens;
    private String mensaje;
    private Analizador_lexico lex;
    private ArrayList<Producciones> product;
    private int x;
    private Producciones aux;
    private Token error;
    
    
    public AnalizadorSintactico(){
        this.mensaje="";
        this.lex=new Analizador_lexico();
        this.product=new ArrayList<Producciones>();
        this.x=0;
    }
    
    public void setTokens(Token[] t){
        this.tokens=t;
    }
    
    public void Program(String cadena){
        this.mensaje="";
        this.lex=new Analizador_lexico();
        this.setTokens(this.lex.Tokenize(cadena));
        Producciones p =new Producciones();
        p.setTipo("programa");
        this.product.add(p);
        this.x=0;
        this.Bloque();
    }
    
    public void Bloque(){
        boolean funciono=true;
        Producciones p =new Producciones();
        p.setTipo("Bloque");
        this.product.add(p);
        
        if(this.tokens[x].getToken().equals("def")){
                funciono=this.fun_decl();
        }
        if(funciono&&this.tokens[x].getLex().equals("Identifier")){
            funciono=this.var_decl();
        }
        if(funciono){
            
            funciono=this.Statement_List();

        }
        
        if(!funciono){
            System.out.println(this.mensaje);
            this.error();
        }
               
    }
    
    public boolean fun_decl() {             //def indent+ ( indent* ) :  endfun
        Producciones p = new Producciones();
        p.setTipo("fun_decl");

        if (x < this.tokens.length && this.tokens[x].getToken().equals("def")) {
            
            p.addTokens(this.tokens[x]);
            this.mensaje += this.tokens[x].getToken() + " ";
            
            if (!this.tokens[x + 1].getLex().equals("Identifier")) {
                
                this.error = tokens[x + 1];
                return false;
                
            } else if (this.tokens[x + 2].getToken().equals("(")) {
                
                p.addTokens(this.tokens[x + 1]);
                p.addTokens(this.tokens[x + 2]);
                this.mensaje += this.tokens[x + 1].getToken() + " ";
                this.mensaje += this.tokens[x + 2].getToken() + " ";
                this.x = x + 3;
                this.product.add(p);
                
                if (!this.ident_list(p)) {
                    return false;
                }
                
                this.x++;
                
                if (this.tokens[x].getToken().equals(")")) {
                    
                    p.addTokens(this.tokens[x]);
                    this.mensaje += this.tokens[x].getToken() + " ";
                    this.x++;
                    
                    if (this.tokens[x].getToken().equals(":")) {
                        
                        p.addTokens(this.tokens[x]);
                        this.mensaje += this.tokens[x].getToken() + "\t #declaracion de funcion \n";
                        this.x++;
                        this.Bloque();
                        if (this.tokens[x].getToken().equals("endfun")) {    
                            p.addTokens(this.tokens[x]);
                            this.mensaje += this.tokens[x].getToken() + "\t #fin de la funcion\n";
                            if(x<this.tokens.length-1){
                                this.x++;
                            }
                            return true;
                            
                        }
                    }
                }
            }
        }
        System.out.println(x);
        this.error = tokens[x];
        return false;
        
    }
    
    public boolean ident_list(Producciones p) {
        if (this.tokens[x].getLex().equals("Identifier")) {
            p.addTokens(this.tokens[x]);
            this.mensaje+=this.tokens[x].getToken()+" ";
            if (this.tokens[x + 1].getToken().equals(",")) {
                p.addTokens(this.tokens[x + 1]);
                this.mensaje+=this.tokens[x + 1].getToken()+" ";
                this.x = x + 2;
                this.ident_list(p);
            } else {
                return true;
            }
        }
        this.error = tokens[x];
        return false;
    }

    public boolean var_decl() {
        Producciones p = new Producciones();
        p.setTipo("var_decl");

        if (this.tokens[x].getLex().equals("Identifier")) {
            p.addTokens(this.tokens[x]);
            this.mensaje+=this.tokens[x].getToken()+" ";
            this.x++;
            if (this.tokens[x].getToken().equals("=")) {
                p.addTokens(this.tokens[x]);
                this.mensaje+=this.tokens[x].getToken()+" ";
                this.x++;;
                if (!this.value()) {
                    return false;
                }
                p.addTokens(this.tokens[x]);
                this.mensaje+=this.tokens[x].getToken()+"\t #declaracion de variable \n";
                if(x<this.tokens.length-1){
                                this.x++;
                }
                if (this.tokens[x].getLex().equals("Identifier")) {
                    this.product.add(p);
                    return this.var_decl();

                } else {
                    this.product.add(p);
                    return true;
                }

            }
        }
        return false;
    }

    public boolean value() {
        if (this.tokens[x].getLex().equals("Identifier")) {
            return true;
        } else if (this.tokens[x].getLex().equals("Number")) {
            return true;
        } else if (this.tokens[x].getLex().equals("String")) {
            return true;
        } else if (this.tokens[x].getToken().equals("true")) {
            return true;
        } else if (this.tokens[x].getToken().equals("false")) {
            return true;
        }
        this.error = tokens[x];
        return false;
    }

    public boolean Statement_List() {
        boolean entro=false;
        if (this.tokens[x].getToken().equals("if")) {
            entro=true;
            if (!this.ifClause()) {
                return false;
            }
        }
        if (this.tokens[x].getToken().equals("while")) {
            entro=true;
            if (!this.whileClause()) {
                return false;
            }
        }
        if (this.tokens[x].getToken().equals("for")) {
            entro=true;
            if (!this.forClause()) {
                return false;
            }
        }
        if (this.tokens[x].getLex().equals("Identifier")) {
            entro=true;
            if (!this.setVar()) {
                return false;
            }
        }
        if(!entro){
            if(aux!=null){
                aux.setHijo(null);
                aux=null;
            }
            return true;
        }else{
            if(aux!=null){
                aux=aux.getHijo();
            }
            return this.Statement_List();
        }
        
    }

    public boolean ifClause() {                 //if ( ident relacional ident ): endif 
        Producciones p = new Producciones();
        p.setTipo("if clause");
        if(aux!=null){
            this.aux.setHijo(p);
             p.setAnidado(true);
        }
        if (this.tokens[x].getToken().equals("if")) {
            p.addTokens(this.tokens[x]);
            this.mensaje+=this.tokens[x].getToken()+" ";
            this.x++;
            if (this.tokens[x].getToken().equals("(")) {
                p.addTokens(this.tokens[x]);
                this.mensaje+=this.tokens[x].getToken()+" ";
                this.x++;
                this.product.add(p);
                if (!this.condition(p)) {
                    return false;
                }
                if (this.tokens[x].getToken().equals(")")) {
                    p.addTokens(this.tokens[x]);
                    this.mensaje+=this.tokens[x].getToken()+" ";
                    this.x++;
                    if (this.tokens[x].getToken().equals(":")) {
                        p.addTokens(this.tokens[x]);
                        this.mensaje+=this.tokens[x].getToken()+"\t #declaracion de clausula if \n";
                        this.x++;
                        this.aux=p;
                        if (!this.Statement_List()) {
                            return false;
                        }
                        if (this.tokens[x].getToken().equals("endif")) {
                            p.addTokens(this.tokens[x]);
                            this.mensaje+=this.tokens[x].getToken()+"\t #fin de clausula if \n";
                            if(x<this.tokens.length-1){
                                this.x++;
                            }
                            return true;
                        }
                    }
                }
            }
            this.error = tokens[x];
            return false;
        }
        this.error = tokens[x];
        return false;
    }

    public boolean whileClause() {            //while ( ident+ logico ident* ) : endw
        Producciones p = new Producciones();
        p.setTipo("while");
        if(aux!=null){
            this.aux.setHijo(p);
             p.setAnidado(true);
        }
        if (this.tokens[x].getToken().equals("while")) {
            p.addTokens(this.tokens[x]);
            this.mensaje+=this.tokens[x].getToken()+" ";
            this.x++;
            if (this.tokens[x].getToken().equals("(")) {
                p.addTokens(this.tokens[x]);
                this.mensaje+=this.tokens[x].getToken()+" ";
                this.x++;
                this.product.add(p);
                if (!this.condition(p)) {
                    return false;
                }
                if (this.tokens[x].getToken().equals(")")) {
                    p.addTokens(this.tokens[x]);
                    this.mensaje+=this.tokens[x].getToken()+" ";
                    this.x++;
                    if (this.tokens[x].getToken().equals(":")) {
                        p.addTokens(this.tokens[x]);
                        this.mensaje+=this.tokens[x].getToken()+"\t declaracion de ciclo while \n ";
                        if(x<this.tokens.length-1){
                                this.x++;
                        }
                        this.aux=p;
                        if (!this.Statement_List()) {
                            return false;
                        }
                        if (this.tokens[x].getToken().equals("endw")) {
                            p.addTokens(this.tokens[x]);
                            this.mensaje+=this.tokens[x].getToken()+"\t fin del ciclo while \n ";
                            if(x<this.tokens.length-1){
                                this.x++;
                            }
                            return true;
                        }
                    }
                }
            }

        }
        this.error = tokens[x];
        return false;
    }

    public boolean forClause() {
        Producciones p = new Producciones();
        p.setTipo("for");

        if(aux!=null){
            this.aux.setHijo(p);
             p.setAnidado(true);
        }
        
        if (this.tokens[x].getToken().equals("for")) {
            p.addTokens(this.tokens[x]);
            this.mensaje+=this.tokens[x].getToken()+" ";
            this.x++;
            if (this.tokens[x].getLex().equals("Identifier")) {
                p.addTokens(this.tokens[x]);
                this.mensaje+=this.tokens[x].getToken()+" ";
                this.x++;
                if (this.tokens[x].getToken().equals("in")) {
                    p.addTokens(this.tokens[x]);
                    this.mensaje+=this.tokens[x].getToken()+" ";
                    this.x++;
                    if (this.tokens[x].getToken().equals("range")) {
                        p.addTokens(this.tokens[x]);
                        this.mensaje+=this.tokens[x].getToken()+" ";
                        this.x++;
                        if (this.tokens[x].getToken().equals("(")) {
                            p.addTokens(this.tokens[x]);
                            this.mensaje+=this.tokens[x].getToken()+" ";
                            this.x++;
                            if (this.tokens[x].getLex().equals("Number")) {
                                p.addTokens(this.tokens[x]);
                                this.mensaje+=this.tokens[x].getToken()+" ";
                                this.x++;
                                if (this.tokens[x].getToken().equals(")")) {
                                    p.addTokens(this.tokens[x]);
                                    this.mensaje+=this.tokens[x].getToken()+" ";
                                    this.x++;
                                    if (this.tokens[x].getToken().equals(":")) {
                                        p.addTokens(this.tokens[x]);
                                        this.mensaje+=this.tokens[x].getToken()+"\t #declaracion de ciclo for \n ";
                                        this.x++;
                                        this.product.add(p);
                                        this.aux=p;
                                        if (!this.Statement_List()) {
                                            return false;
                                        }
                                        if (this.tokens[x].getToken().equals("endfor")) {
                                            p.addTokens(this.tokens[x]);
                                            this.mensaje+=this.tokens[x].getToken()+"\t #fin del ciclo for \n ";
                                            if(x<this.tokens.length-1){
                                                this.x++;
                                            }
                                            return true;
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
        this.error = tokens[x];
        return false;
    }

    public boolean setVar() { //ident assign ident|number|string ( aritmetic ident|number|string)*
        int z = 0;
        Producciones p = new Producciones();
        Producciones p2 = new Producciones();
        p2.setTipo("expression");
        if(aux!=null){
            this.aux.setHijo(p);
            p.setAnidado(true);
            p2.setAnidado(true);
        }
        p.setTipo("Assign");
        if (tokens[x].getLex().equals("Identifier")) {
            p.addTokens(tokens[x]);
            this.mensaje+=this.tokens[x].getToken()+" ";
            this.x++;
            if (tokens[x].getLex().equals("Assign op")) {
                p.addTokens(tokens[x]);
                this.mensaje+=this.tokens[x].getToken()+" ";
                this.x++;
                this.product.add(p);
                p.setHijo(p2);
                if(!this.expression(p2,p)){
                    return false;
                }
                this.mensaje+="\t #asignacion de variable\n";
                if(x==this.tokens.length){
                    this.x--;
                }
                return true;
            }
        }
        this.error = tokens[x];
        return false;
    }

    public boolean condition(Producciones p) {
        Producciones p3 = new Producciones();
        Producciones con= new Producciones();
        p3.setTipo("relacion");
        if (this.tokens[x].getLex().equals("Identifier")) {
            if (this.tokens[x + 1].getToken().equals(")")) {
                p.addTokens(this.tokens[x]);
                con.addTokens(this.tokens[x]);
                this.mensaje+=this.tokens[x].getToken()+" ";
                this.x = this.x + 1;
                p.setCondicion(con);
                return true;
            }
        } 
            
        Producciones p1 = new Producciones();
        p1.setTipo("Expression");
        if (!this.expression(p1,con)) {
            return false;
        }
        if (this.tokens[x].getLex().equals("Relational op")) {
            p3.addTokens(tokens[x]);
            con.addTokens(tokens[x]);
            this.mensaje+=this.tokens[x].getToken()+" ";
            this.x++;
            Producciones p2 = new Producciones();
            p2.setTipo("Expression");
            p.setCondicion(con);
            return this.expression(p2,con);
        }
        
        this.error = tokens[x];
        return false;
    }

    public boolean expression(Producciones p,Producciones p2) {
        if (!this.value()) {
            this.error = tokens[x];
            return false;
        } else {
            p.addTokens(this.tokens[x]);
            p2.addTokens(this.tokens[x]);
            this.mensaje+=this.tokens[x].getToken()+" ";
            if(x+1<this.tokens.length){
            if (this.tokens[x + 1].getLex().equals("Aritmetic op")) {
                p.addTokens(this.tokens[x + 1]);
                p2.addTokens(this.tokens[x+1]);
                this.mensaje+=this.tokens[x + 1].getToken()+" ";
                this.x = this.x + 2;
                return this.expression(p,p2);
            } else {
                this.x = this.x + 1;
                this.product.add(p);
                return true;
            }
            }else {
                this.product.add(p);
                return true;
            }

        }
    }

    public void error() {
        
        this.mensaje = "ocurrio un error en el analisis sintactico, en la linea "
                + this.error.getLinea() + " en la columna " + this.error.getCol()+"\t"+this.error.getToken();

    }

    public String getMensaje() {
        return this.mensaje;
    }

    public ArrayList<Producciones> getProduct() {
        return this.product;
    }

}
