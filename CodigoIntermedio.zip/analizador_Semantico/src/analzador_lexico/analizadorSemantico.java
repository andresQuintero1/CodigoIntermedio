/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package analzador_lexico;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;

/**
 *
 * @author FELIPE
 */
public class analizadorSemantico {
    
    private ArrayList<Producciones> cadenas;
    private String error;
    private AnalizadorSintactico sem;
    private HashMap<String, String> variables;
    private int cont;
    private int cont2;
    
    public analizadorSemantico(){
        this.variables=new HashMap<>();
        this.variables.put("String","cadena");
        this.variables.put("Number","numero");
        this.variables.put("true","boolean");
        this.variables.put("false","boolean");
        this.variables.getOrDefault("algo", "vacio");
        this.sem= new AnalizadorSintactico();
        this.cont=1;
        this.cont2=1;
    }
    
    public void inicializarHash(){
        this.variables=new HashMap<>();
        this.variables.put("String","cadena");
        this.variables.put("Number","numero");
        this.variables.put("true","boolean");
        this.variables.put("false","boolean");
        this.variables.getOrDefault("algo", "vacio");
        this.error="Todo esta correcto semanticamente";
        this.cont=1;
    }
    public void Sintactico(String prog){
        this.sem=new AnalizadorSintactico();
        this.sem.Program(prog);
    }
        
    public String getProgram(){
        return this.sem.getMensaje();
    }
    
    public void analizar(String prog){
        this.inicializarHash();
        this.Sintactico(prog);
        System.out.println(this.variables.toString());
        this.cadenas=sem.getProduct();
        
        for(Producciones pro : this.cadenas){
            System.out.println(pro.getTipo());
            if(pro.getTipo().equals("while")){
                if(!this.ciclo(pro)){
                    return;
                }
            }else if (pro.getTipo().equals("Assign")){
                //System.out.println(this.cadenas.get(this.cadenas.indexOf(pro)+1).StringTokens());
                //System.out.println(this.cadenas.get(this.cadenas.indexOf(pro)+1).getTipo());
                if(!this.asignacion(pro,this.cadenas.get(this.cadenas.indexOf(pro)+1))){
                    return;
                }
            
            }else if(pro.getTipo().equals("if clause")){
                if(!this.ciclo(pro)){
                    return;
                }
                
            }else if(pro.getTipo().equals("for")){
                if(!this.cicloFor(pro)){
                    return;
                }
            }else if(pro.getTipo().equals("var_decl")){
                if(!this.declaracionVar(pro)){
                    return;
                }
                
            }else if(pro.getTipo().equals("fun_decl")){
                    if(!this.fun_decl(pro)){
                    return;
                }
            }
        }
    }
    
    public boolean ciclo(Producciones p){
        Producciones q,r;
        if(!this.cadenas.get(this.cadenas.indexOf(p)+1).getTipo().equals("Expression")){
           if(this.variables.containsKey(p.getToken(2))){
               if(this.variables.getOrDefault((p.getToken(2)), "vacio").equals("boolean")){
                   return true;
               }else{
                   this.error="no se puede hacer comparaciones con una varible "+p.getToken(2)
                           +"de tipo "+this.variables.getOrDefault((p.getToken(2)), "vacio");
                   return false;
               }
           }else{
               this.error="la variable "+p.getToken(2)+" no se ha inicializado ";
               return false;
           } 
        }else if(this.cadenas.get(this.cadenas.indexOf(p)+2).getTipo().equals("Expression")){
            q=this.cadenas.get(this.cadenas.indexOf(p)+1);
            r=this.cadenas.get(this.cadenas.indexOf(p)+2);
            for(int i=0;i<q.getTokens().size();i=i+2){
               if(!"numero".equals(this.variables.getOrDefault((q.getlex(i)), "vacio"))){
                   if(!"numero".equals(this.variables.getOrDefault((q.getToken(i)), "vacio"))){
                        this.error="no se puede usar la variable "+q.getToken(i)+" de tipo "+
                           this.variables.getOrDefault((q.getlex(i)), "vacio")+" para hacer comparaciones con operadores relaciones" ;
                        return false;
                   }
               }
            }
            for(int j=0;j<r.getTokens().size();j=j+2){
               if(!"numero".equals(this.variables.getOrDefault((q.getlex(j)), "vacio"))){
                   if(!"numero".equals(this.variables.getOrDefault((q.getToken(j)), "vacio"))){
                        this.error="no se puede usar la variable "+q.getToken(j)+" de tipo "+
                           this.variables.getOrDefault((q.getlex(j)), "vacio")+" para hacer comparaciones con operadores relaciones" ;
                        return false;
                   }
               } 
            }
            return true;
        }else{
            System.out.println(this.cadenas.get(this.cadenas.indexOf(p)+3).getTipo());
            this.error="hay un error en las condiciones del while";
            return false;
            
        }
    }
    
        
    public boolean asignacion(Producciones p,Producciones q){
        String value="";
        boolean existe=false;
        String valor="";
        
        if(this.variables.containsKey(p.getToken(0))){
            value=this.variables.get(p.getToken(0));
            existe=true;
        }
        if(q.getTipo().equals("expression")){
            if(q.getlex(0).equals("Identifier")){
                if(value.equals("")){
                    value=this.variables.get(q.getToken(0));
                }
            }else if(value.equals("")){
                value=this.variables.get(q.getlex(0));
            }for(int i=0;i<q.getTokens().size();i=i+2){
                if(q.getlex(i).equals("Identifier")){
                    valor=q.getToken(i);
                }else{
                    valor=q.getlex(i);
                }
                if(!value.equals(this.variables.getOrDefault(valor, "vacio"))){
                   this.error="no se puede asignar una variable "+q.getToken(i)+" de tipo "+
                           this.variables.getOrDefault(valor, "vacio")+" a una variable "+q.getlex(0)+" de tipo "+value;
                   return false;
               } 
            }
            if(!existe){
                this.variables.put(p.getToken(0), value);
                return true;
            }
            return true;
        }
        
        return false;
    }
    
    public boolean cicloFor(Producciones p){
        if(this.variables.containsKey(p.getToken(1))){
            if(!this.variables.get(p.getToken(1)).equals("numero")){
                this.error="el identificador "+p.getToken(1)+" usado en el ciclo "
                        + "for ya esta siendo usado y no es de tipo numerico";
                return false;
            }else{
                return true;
            }
        }else{
            this.variables.put(p.getToken(1),"numero");
            return true;
        }  
    }
    
    public boolean declaracionVar(Producciones p){
        if(this.variables.containsKey(p.getToken(0))){
            if(!this.variables.get(p.getToken(0)).equals(this.variables.get(p.getlex(2)))){
                this.error="La variable "+p.getToken(0)+" es de tipo "+
                        this.variables.get(p.getToken(0)) +
                        " y no se puede asignar un valor "+
                        this.variables.get(p.getlex(2));
                        return false;
            }else{
                return true;
            }
        }else{
            this.variables.put(p.getToken(0),this.variables.get(p.getlex(2)));
            return true;
        }
    }
        
    public boolean fun_decl(Producciones p){
        if(this.variables.containsKey(p.getToken(1))){
            this.error="el identificador "+p.getToken(1)+" ya se esta utilizando";
            return false;
        }
        this.variables.put(p.getToken(1), "funcion");
        return true;
    }
    
    public void printError(){
        System.out.println(this.error);
    }
    
    public String getMensaje(){
        return this.error;
    }
    
    public String getTipos(){
        String mensaje[]=this.variables.toString().split(" ");
        String mensaje1="";
        for(int i=0;i<mensaje.length;i++){
            mensaje1+=mensaje[i]+"\n";
        }
        return mensaje1;
    }
    
    public String generarCodigo(){
        String mensaje="";
        System.out.println("se genera codigo");
        for(Producciones pro : this.cadenas){
            if(!pro.isAnidado()){
                if(pro.getTipo().equals("if clause")){
                    mensaje+=this.ifMedio(pro);
                }else if(pro.getTipo().equals("while")){
                    mensaje+=this.WhileMedio(pro);
                }else if(pro.getTipo().equals("for")){
                    mensaje+=this.ForMedio(pro);
                }else if(pro.getTipo().equals("Assign")){
                    mensaje+=this.AsignMedio(pro);
                }else if(pro.getTipo().equals("var_decl")){
                    mensaje+=pro.StringTokens()+";\n";
                }
            }
        }
        System.out.println("\n\nCodigoIntermedio\n");
        System.out.println(mensaje);
        return mensaje;
    }
    
    public String ifMedio(Producciones pro){
        int x=0;
        Producciones son=pro.getHijo();
        String mensaje="";
        
        mensaje+=("if("+pro.condition()+") goto L"+this.cont+";\n");
        mensaje+=("goto L"+(this.cont+1)+";\n");
        mensaje+=("L"+this.cont+":\n");
        x=this.cont+1;
        this.cont=this.cont+2;
        if(son!=null){
            mensaje+=this.elegir(son);
        }
        mensaje+=("L"+x+":\n");
        return mensaje;
    }
    
    public String WhileMedio(Producciones pro){
        int x=0;
        Producciones son=pro.getHijo();
        String mensaje="";
        mensaje+=("L"+this.cont+":\n");
        mensaje+=("if("+pro.condition()+")goto L"+(this.cont+1)+";\n");
        mensaje+=("goto L"+(this.cont+2)+";\n");
        mensaje+=("L"+(this.cont+1)+":\n");
        x=this.cont+2;
        this.cont=this.cont+3;
        if(son!=null){
            mensaje+=this.elegir(son);
        }
        mensaje+=("goto L"+(x-2)+";\n");
        mensaje+=("L"+x+":\n");    
        return mensaje;
    }
    
    public String ForMedio(Producciones pro){
        int x;
        Producciones son=pro.getHijo();
        String mensaje="";
        mensaje+=(pro.getToken(1)+"=0;\n");
        mensaje+=("L"+this.cont+":if("+pro.getToken(1)+"<"
                +pro.getToken(5)+") goto L"+(this.cont+1)+";\n");
        mensaje+=("goto L"+(this.cont+2)+";\n");
        mensaje+=("L"+(this.cont+3)+":\n");
        mensaje+=(pro.getToken(1)+"="+pro.getToken(1)+"+"+
                "1;\n");
        mensaje+=("goto L"+this.cont+";\n");
        mensaje+=("L"+(this.cont+1)+":\n");
        x=this.cont;
        this.cont=this.cont+4;
        if(son!=null){
            mensaje+=this.elegir(son);
        }
        mensaje+=("goto L"+(x+3)+";\n");
        mensaje+=("L"+(x+2)+":\n");
        
        return mensaje;
    }
    
    public String AsignMedio(Producciones pro){
        int x;
        int i=0;
        int n=-1;
        Producciones son=pro.getHijo();
        String mensaje="";
        String op="";
        System.out.println(pro.StringTokens());   
        ArrayList<String> z;
        if(son==null){
            mensaje=pro.StringTokens();
        }else{
            op=son.StringTokens();
            System.out.println(son.StringTokens());
            z=new ArrayList<String>(Arrays.asList(op.split("\\s+")));
            System.out.println(z.toString());
            while(z.size()!=2){
                if(z.contains("**")){
                    if(z.get(i).equals("**")){
                        n=i;
                    }
                }else if(z.contains("%")){
                    if(z.get(i).equals("%")){
                        n=i;
                    }
                }else if(z.contains("*")){
                    if(z.get(i).equals("*")){
                        n=i;
                    }
                }
                else if(z.contains("//")){
                    if(z.get(i).equals("//")){
                        n=i;
                    }
                }else if(z.contains("/")){
                    if(z.get(i).equals("/")){
                        n=i;
                    }
                }else if(z.contains("+")){
                    if(z.get(i).equals("+")){
                        n=i;
                    }
                }else if(z.contains("-")){
                    if(z.get(i).equals("¨-")){
                        n=i;
                    }
                }
                
                if(n!=-1){
                    mensaje+=("t_"+this.cont2+"= "+z.get(i-1)+z.get(i)+z.get(i+1)+";\n");
                    z.set(i,("t_"+this.cont2));
                    z.remove(i+1);
                    z.remove(i-1);
                    this.cont2++;
                    i=-1;
                    n=-1;
                    System.out.println(z.toString()); 
                }
            i++;
        }
            mensaje+=pro.getToken(0)+"="+z.get(1)+";\n";
        }
        return mensaje;
    }
    
    public String elegir(Producciones son){
        String mensaje="";
            if(son.getTipo().equals("if clause")){
                mensaje+=this.ifMedio(son);
            }else if(son.getTipo().equals("while")){
                mensaje+=this.WhileMedio(son);
            }else if(son.getTipo().equals("for")){
                mensaje+=this.ForMedio(son);
            }else if(son.getTipo().equals("Assign")){
                mensaje+=this.AsignMedio(son);
            }
        return mensaje;
    }
}
