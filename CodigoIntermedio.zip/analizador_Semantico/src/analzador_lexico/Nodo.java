/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package analzador_lexico;

/**
 *
 * @author FELIPE
 */
public class Nodo {
    private Producciones referencia;
    private Nodo hijo1;
    private Nodo hijo2;
    private Nodo Hijo3;
    
}
